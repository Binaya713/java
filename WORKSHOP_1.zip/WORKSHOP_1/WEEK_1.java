/*	package WORKSHOP_1;

import java.util.*;
public class WEEK_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String say ="some data";
		System.out.println("Hey There \n I am "+ say);

		int a =45;
		int b = 32;
		int sum = a+b;
		int diff = a-b;
		System.out.println("The sum of the given number "+a+ " and "+ 32 + " is " +sum);

		System.out.println("The difference of the given number "+a+ " and "+ 32 + " is " +diff);
		
		
		int a = 1;
		double b = 1.1;
		char c = 'C';
		
		System.out.println("int = "+ a +"\ndouble = "+ b + "\nCharacter = "+ c);
		
	
	int a =5;
	int b =6;
	int c = 3;
	double s = (a+b+c)/2;
	double area = Math.sqrt(s*((s-a)*(s-b)*(s-c)));
	
	System.out.println("The area of the triangle is "+area);
	
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter a side of a sqaure: ");
		double side = sc.nextDouble();
		double area_square = side*side ;
		System.out.println("The area of the square is "+area_square);
	
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a celsius: ");
		double celsius = scanner.nextDouble();
		double fahrenheit = celsius*(9/5)+32;
		System.out.println(celsius+" celsius is " +fahrenheit+ " fahrenheit.");
		
		
		
		Scanner a = new Scanner (System.in);
		System.out.println("Enter a radius of a cylinder : ");
		double radius = a.nextDouble();
		System.out.println("Enter a height of a cylinder : ");
		double height = a.nextDouble();
	
		
		double volume_cylinder = Math.PI*radius*radius*height;
		
		System.out.println("The volume of the cylinder : "+ volume_cylinder);
		
		
		Scanner SI = new Scanner (System.in);
		System.out.println("Enter the principle amount : ");
		int P = SI.nextInt();
		System.out.println("Enter the rate of interest : ");
		int R = SI.nextInt();
		System.out.println("Enter the time period : ");
		int T = SI.nextInt();
		
		double simple_interest = (P*R*T)/100;
		
		System.out.println("Simple interest = "+simple_interest);
		
		
		Scanner h = new Scanner (System.in);
		System.out.println("Enter a first number :");
		int a = h.nextInt();	
		System.out.println("Enter a second number :");
		int b = h.nextInt();
		int add = a+b;
		int sub = a-b;
		int mull = a*b;
		int div = a/b;
		
		System.out.println(add + sub + mull + div );
		
		
				
	}

}

		
		
			   Scanner sc = new Scanner(System.in);
			   System.out.println("enter the number ");
			   double l = sc.nextDouble();
			  
			   System.out.println("enter the number ");
			   double b = sc.nextDouble();
			   
			  double p = 2*(l+b);
			   
			   System.out.println(p);
			        
			    }
}
		
		

			   Scanner sc = new Scanner(System.in);
			   System.out.println("enter the miles ");
			   double m = sc.nextDouble();
			  
			   
			   
			  double km = m*1.6;
			   
			   System.out.println(km + "km");
			        
			    }
}
		
		
		

			   Scanner sc = new Scanner(System.in);
			   System.out.println("enter the radius ");
			   double r = sc.nextDouble();
			  
			   double ar = (22/7)* r*r;
			   
			   System.out.println(ar);
			        
			    }
	}
		
		
		

			   Scanner sc = new Scanner(System.in);
			   System.out.println("enter the quantity ");
			   double q = sc.nextDouble();
			   System.out.println("enter the total price ");
			   double tp = sc.nextDouble();
			  
			   double total = q*tp; 
			   
			   System.out.println("the total ammount is " + total);
			        
			    }
	}
		
		*/
package WORKSHOP_1;


		
		